const {ApiModel} = require('./../models/apiModel');

const ApiController = {

    getPeople: function(request, response) {
    ApiModel
        .getPeople()
        .then(people => response.json(people))
        .catch(error => response.json(error));
},
    getOnePerson: function (request, response) {
    ApiModel
        .getOnePerson(request.params)
        .then(person => {
        response.json(person ? person : 'No such person existed in 1955!!');
        })
        .catch(error => response.json(error));
},
    createPerson: function (request, response) {
    //console.log(request.params);
        ApiModel
        .createPerson(request.params)
        .then(person => response.json(person))
        .catch(error => response.json(error));
},
    deletePerson: function(request, response) {
    ApiModel
        .deletePerson(request.params)
        .then(result => response.json(result))
        .catch(error => response.json(error));
    },
};

module.exports = {ApiController};