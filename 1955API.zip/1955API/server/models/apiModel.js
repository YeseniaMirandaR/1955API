const mongoose = require('mongoose');

const ApiSchema = new mongoose.Schema({
    name: {
    type: String,
    required: true,
    }
});

const People = mongoose.model( 'people', ApiSchema );
const ApiModel = {

    createPerson : function( newPerson ){
        return People.create( newPerson );
    },
    getPeople : function(){
        return People.find();
    },
    getOnePerson : function( name ){
        return People.findOne( name );
    },
    deletePerson : function( name ){
        return People.deleteOne( name );
    }
};

module.exports = {ApiModel};
