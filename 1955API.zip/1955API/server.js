const express = require('express');
const bodyParser = require('body-parser');
const {ApiRouter} = require('./server/routes/apiRouter');
require( './server/config/database' );

const app = express();

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/', ApiRouter);

app.listen(8000, function(){
    console.log( "The server is running in port 8000");
});