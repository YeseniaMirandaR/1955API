const express = require('express');
const {ApiController} = require('../controllers/apiController');

const ApiRouter = express.Router();

ApiRouter
  .get("/", ApiController.getPeople);

ApiRouter
  .get("/new/:name/", ApiController.createPerson);

ApiRouter
  .get("/remove/:name", ApiController.deletePerson);

ApiRouter
  .get("/:name", ApiController.getOnePerson);

module.exports = {ApiRouter};

